export const lightTheme = {
  background: "#FFFFFF",
  text: "#111111",
  card: "#F5F5F5",
  button: "#222222",
  buttonText: "#FFFFFF",
};
