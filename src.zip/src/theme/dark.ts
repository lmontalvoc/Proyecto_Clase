export const darkTheme = {
  background: "#000000",
  text: "#FFFFFF",
  card: "#1A1A1A",
  button: "#FFFFFF",
  buttonText: "#000000",
};
