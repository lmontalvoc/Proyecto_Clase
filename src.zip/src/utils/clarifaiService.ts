export async function identifyImage(base64Image: string) {
  const apiKey = process.env.EXPO_PUBLIC_CLARIFAI_API_KEY;

  if (!apiKey) {
    console.log("❌ ERROR: Clarifai API Key no está definida en .env");
    return null;
  }

  try {
    const response = await fetch(
      "https://api.clarifai.com/v2/models/general-image-recognition/outputs",
      {
        method: "POST",
        headers: {
          Authorization: `Key ${apiKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          inputs: [
            {
              data: {
                image: { base64: base64Image },
              },
            },
          ],
        }),
      }
    );

    const data = await response.json();

    const concepts = data?.outputs?.[0]?.data?.concepts;
    if (!concepts) return "Objeto no identificado";

    return concepts[0].name;
  } catch (error) {
    console.log("❌ Error con Clarifai:", error);
    return null;
  }
}
